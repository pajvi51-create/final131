# โค้ดข้อสอบกลางภาค (Kotlin + Java source folder)

ผู้จัดทำ: กฤษฎา ศรีคิลิน  
รหัสนักศึกษา: 67102122111

## ข้อ 1 — Activity Lifecycle

ไฟล์: `java/com/example/myapplication/MainActivity.kt`

- `MainActivity` และ Lifecycle callbacks: `onCreate`, `onStart`, `onResume`, `onPause`, `onStop`, `onDestroy`
- `showLifecycle()` แสดง Toast และบันทึก Logcat
- `MissionScreen()` แสดงข้อมูลนักศึกษาและรายละเอียด Lifecycle

## ข้อ 2 — State Hoisting และแผนที่

ไฟล์: `java/com/example/myapplication/MainActivity.kt`

- `MapScreen()` เป็น Stateful Composable และตรวจสอบ Latitude/Longitude
- `CoordinateField()` รับ value และ callback จาก parent ตามหลัก State Hoisting
- `OpenStreetMap()` แสดงแผนที่แบบ Native โดยไม่ต้องใช้ API key
- `openGoogleMaps()` สาธิต Implicit Intent เปิดสถานที่ใน Google Maps

## ข้อ 3 — MVVM เครื่องคำนวณค่างวด

- Model: `java/com/example/myapplication/InstallmentModel.kt`
- ViewModel: `java/com/example/myapplication/InstallmentViewModel.kt`
- View: `InstallmentScreen()` ใน `java/com/example/myapplication/MainActivity.kt`
- Unit tests: `test/com/example/myapplication/InstallmentCalculatorTest.kt` และ `InstallmentViewModelTest.kt`

## Theme และ UI

ไฟล์อยู่ใน `java/com/example/myapplication/ui/theme/` ได้แก่ `Color.kt`, `Theme.kt` และ `Type.kt`

หมายเหตุ: โฟลเดอร์ `java` ของ Android รองรับไฟล์ Kotlin (`.kt`) และ Java (`.java`) ร่วมกัน โปรเจกต์นี้พัฒนาด้วย Kotlin จึงไม่มีไฟล์ `.java`
